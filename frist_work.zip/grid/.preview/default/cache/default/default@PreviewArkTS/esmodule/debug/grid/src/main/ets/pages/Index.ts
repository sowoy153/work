if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PhotoGridExample_Params {
    photos?: string[];
}
class PhotoGridExample extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__photos = new ObservedPropertyObjectPU([
            'https://tse3-mm.cn.bing.net/th/id/OIP-C.g9UbVfyVZX-SfD09JcYr5QHaEK?rs=1&pid=ImgDetMain',
            'https://img.ixintu.com/download/jpg/202001/44072e871c313c26f1360be607283cdd.jpg!ys',
            'https://ts1.cn.mm.bing.net/th/id/R-C.57384e4c2dd256a755578f00845e60af?rik=uy9%2bvT4%2b7Rur%2fA&riu=http%3a%2f%2fimg06file.tooopen.com%2fimages%2f20171224%2ftooopen_sy_231021357463.jpg&ehk=whpCWn%2byPBvtGi1%2boY1sEBq%2frEUaP6w2N5bnBQsLWdo%3d&risl=&pid=ImgRaw&r=0',
            'https://ts1.cn.mm.bing.net/th/id/R-C.31df3a5a2d8462228734f95d459883e2?rik=7EE6TeWDk%2f%2bctQ&riu=http%3a%2f%2fwww.quazero.com%2fuploads%2fallimg%2f140303%2f1-140303214331.jpg&ehk=SpI7mz%2byLqOkT8BL79jcd3iCtQYNFlBHQzbtF1p0vuQ%3d&risl=&pid=ImgRaw&r=0',
            'https://ts1.cn.mm.bing.net/th/id/R-C.66d7b796377883a92aad65b283ef1f84?rik=sQ%2fKoYAcr%2bOwsw&riu=http%3a%2f%2fwww.quazero.com%2fuploads%2fallimg%2f140305%2f1-140305131415.jpg&ehk=Hxl%2fQ9pbEiuuybrGWTEPJOhvrFK9C3vyCcWicooXfNE%3d&risl=&pid=ImgRaw&r=0',
            'https://tse3-mm.cn.bing.net/th/id/OIP-C.cGjCuP5ghtV5SuGhFWIqUAHaHa?rs=1&pid=ImgDetMain',
            'https://pic2.zhimg.com/v2-0dda71bc9ced142bf7bb2d6adbebe4f0_r.jpg?source=1940ef5c',
            'https://ts1.cn.mm.bing.net/th/id/R-C.e095e6cf39baa7d349d45c4c1c6f5f78?rik=%2fJXDWPsR3VaxVw&riu=http%3a%2f%2fimg.sj33.cn%2fuploads%2fallimg%2f200912%2f20091223150330493.jpg&ehk=TJoSjF68pWq6vl0NHUl8RTUroI2xHptF83Im%2b0RVWnc%3d&risl=&pid=ImgRaw&r=0',
            'https://tse4-mm.cn.bing.net/th/id/OIP-C.YKoZzgmubNBxQ8j-mmoTKAHaEK?rs=1&pid=ImgDetMain',
            'https://img.zcool.cn/community/015153563ec9e66ac7259e0fc2d030.jpg@3000w_1l_0o_100sh.jpg',
            'https://bpic.588ku.com/back_origin_min_pic/20/04/19/f753e29e3dbe2ad75b8f6d6053199faa.jpg',
            'https://tse4-mm.cn.bing.net/th/id/OIP-C.6szqS1IlGtWsaiHQUtUOVwHaQC?rs=1&pid=ImgDetMain',
            'https://img.zcool.cn/community/01772057f7b93ca84a0e282b26108c.JPG@2o.jpg',
            'https://pic3.zhimg.com/v2-87d78fc44236a144aa52cd8ea18e9da2_r.jpg',
            'https://pic1.zhimg.com/v2-b57e8788ab7ba92d0093a0d0933b3538_r.jpg?source=1940ef5c',
            'https://img.zcool.cn/community/01a88459ae0d88a801211d250cb394.jpg@1280w_1l_2o_100sh.jpg',
            'https://pic4.zhimg.com/v2-14098590ffdbf8a4a3e0db52c07fdded_r.jpg?source=1940ef5c',
            'https://img.zcool.cn/community/01f8115545963d0000019ae943aaad.jpg@1280w_1l_2o_100sh.jpg',
            'https://img95.699pic.com/photo/50079/3337.jpg_wh860.jpg',
            'https://ts1.cn.mm.bing.net/th/id/R-C.2a6d9ad38dd2ec831d3fb01f11e30d82?rik=lPLWAVWvZHZxDA&riu=http%3a%2f%2fseopic.699pic.com%2fphoto%2f40054%2f1002.jpg_wh1200.jpg&ehk=NxURVbGtLSDFkRiXqySb8Nsa3KV6U41BbFcI0zZg2%2fw%3d&risl=&pid=ImgRaw&r=0',
            'https://tse1-mm.cn.bing.net/th/id/OIP-C.5FbjfkeEiu5ne5e7IjLqJgHaEo?rs=1&pid=ImgDetMain',
            'https://pic1.zhimg.com/v2-52058603cf3391b260d4fd0941363d48_r.jpg?source=1940ef5c',
            'https://img.zcool.cn/community/010de95a01bbada801216a4b9c1ac0.JPG@3000w_1l_2o_100sh.jpg',
            'https://xiazai-fd.zol-img.com.cn/t_s960x600/g1/M08/03/06/Cg-4jlONlQyIVQHzAAePQGhUYfoAAN9UAN1jLcAB49Y675.jpg',
            'https://ts1.cn.mm.bing.net/th/id/R-C.148a4f2a5c1e64dba8ffa43c650345e3?rik=yTYoO1j%2fEWZkxQ&riu=http%3a%2f%2fseopic.699pic.com%2fphoto%2f50047%2f7161.jpg_wh1200.jpg&ehk=E3kxXPOt3WNVmFh2GRWUkzMuX6N11jviTq5tbGCUpLE%3d&risl=&pid=ImgRaw&r=0',
            'https://ts1.cn.mm.bing.net/th/id/R-C.80b857f9248a757db90bf90e068f0477?rik=l7S5XkViYu9Bxw&riu=http%3a%2f%2fseopic.699pic.com%2fphoto%2f40095%2f9084.jpg_wh1200.jpg&ehk=F75PL9CVAzBgJzo2q51I103gN1KsrnrjPG7F4n%2fyrj4%3d&risl=&pid=ImgRaw&r=0',
            'https://img.zcool.cn/community/01e96f55451e4d0000019ae99de4d1.jpg@1280w_1l_2o_100sh.jpg',
            'https://ts1.cn.mm.bing.net/th/id/R-C.1b2a81b65ece818eaaaf3f73b901afb9?rik=OrIsFXMzT3BEOw&riu=http%3a%2f%2fseopic.699pic.com%2fphoto%2f40020%2f8732.jpg_wh1200.jpg&ehk=nfxwqjvT9hI%2fecgQhmnaTdNsssGbKpS%2bwFCgJghKueY%3d&risl=&pid=ImgRaw&r=0',
            'https://img-u-4.51miz.com/Templet/00/25/31/78/253178_22810aa0a7fc346d56b1762df3230022.jpg',
            'https://tse1-mm.cn.bing.net/th/id/OIP-C.jdP04yEoxG10mcywseQj7gAAAA?rs=1&pid=ImgDetMain',
            'https://img.keaitupian.cn/newupload/08/1628502171175140.jpg',
            'https://ts1.cn.mm.bing.net/th/id/R-C.f6d48454537423a60d3e2b7b10d99788?rik=lBsO%2f%2fhbDycotg&riu=http%3a%2f%2fpic.52112.com%2f180610%2fJPG-180610_685%2fHZWUaExN5u_small.jpg&ehk=4Q4aq4kxZUjqbTeCb1itTshO6WVhGpqfIktNpH%2f%2bBN0%3d&risl=&pid=ImgRaw&r=0'
        ], this, "photos");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PhotoGridExample_Params) {
        if (params.photos !== undefined) {
            this.photos = params.photos;
        }
    }
    updateStateVars(params: PhotoGridExample_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__photos.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__photos.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __photos: ObservedPropertyObjectPU<string[]>;
    get photos() {
        return this.__photos.get();
    }
    set photos(newValue: string[]) {
        this.__photos.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("grid/src/main/ets/pages/Index.ets(40:5)");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Top UI with Select, Weibo, and Done
            Column.create();
            Column.debugLine("grid/src/main/ets/pages/Index.ets(42:7)");
            // Top UI with Select, Weibo, and Done
            Column.width('100%');
            // Top UI with Select, Weibo, and Done
            Column.margin({ top: 5 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 使用Row布局来放置顶部的按钮和文本
            Row.create();
            Row.debugLine("grid/src/main/ets/pages/Index.ets(44:9)");
            // 使用Row布局来放置顶部的按钮和文本
            Row.height(50);
            // 使用Row布局来放置顶部的按钮和文本
            Row.padding({ left: 0, right: 0 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 设置按钮的点击事件
            Button.createWithLabel('选择');
            Button.debugLine("grid/src/main/ets/pages/Index.ets(46:11)");
            // 设置按钮的点击事件
            Button.width(100);
            // 设置按钮的点击事件
            Button.height(50);
            // 设置按钮的点击事件
            Button.margin({ right: 70 });
        }, Button);
        // 设置按钮的点击事件
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 微博文本，使用Text组件
            Text.create('微博');
            Text.debugLine("grid/src/main/ets/pages/Index.ets(52:11)");
            // 微博文本，使用Text组件
            Text.fontSize(20);
            // 微博文本，使用Text组件
            Text.width(90);
            // 微博文本，使用Text组件
            Text.height(50);
        }, Text);
        // 微博文本，使用Text组件
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 设置按钮的点击事件
            Button.createWithLabel('完成');
            Button.debugLine("grid/src/main/ets/pages/Index.ets(58:11)");
            // 设置按钮的点击事件
            Button.width(100);
            // 设置按钮的点击事件
            Button.height(50);
            // 设置按钮的点击事件
            Button.margin({ left: 0 });
        }, Button);
        // 设置按钮的点击事件
        Button.pop();
        // 使用Row布局来放置顶部的按钮和文本
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Grid.create();
            Grid.debugLine("grid/src/main/ets/pages/Index.ets(66:9)");
            Grid.columnsTemplate('repeat(4, 1fr)');
            Grid.rowsTemplate('repeat(8, 1fr)');
            Grid.width('100%');
            Grid.height('100%');
        }, Grid);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const photoUrl = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.debugLine("grid/src/main/ets/pages/Index.ets(68:13)");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create(photoUrl);
                            Image.debugLine("grid/src/main/ets/pages/Index.ets(69:15)");
                            Image.width('100%');
                            Image.height('100%');
                        }, Image);
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
            };
            this.forEachUpdateFunction(elmtId, this.photos, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        Grid.pop();
        // Top UI with Select, Weibo, and Done
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "PhotoGridExample";
    }
}
registerNamedRoute(() => new PhotoGridExample(undefined, {}), "", { bundleName: "com.example.frist_work", moduleName: "grid", pagePath: "pages/Index", pageFullPath: "grid/src/main/ets/pages/Index", integratedHsp: "false" });
